package com.voicephone

import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * พอร์ตจาก vc.js: รับสถานะจาก Minecraft (พอร์ต 19131, เฉพาะในเครื่อง)
 * และเป็นเซิร์ฟเวอร์รีเลย์เสียง (พอร์ต 8080) ให้ทุกคน
 */
class HostServer(private val log: (String) -> Unit) {
    class Player(var name: String) {
        @Volatile var range = 30
        @Volatile var muted = false
        @Volatile var call = ""
        @Volatile var pos: DoubleArray? = null
        @Volatile var dim = 0
        @Volatile var seen = System.currentTimeMillis()
    }

    private class Client(val id: Int) { @Volatile var name: String? = null }

    private val players = ConcurrentHashMap<String, Player>()
    private val pending = ConcurrentHashMap<String, String>()
    private val clients = ConcurrentHashMap<WebSocket, Client>()
    private val nextId = AtomicInteger(0)
    private val scheduler = Executors.newScheduledThreadPool(1)
    @Volatile private var mc: WebSocket? = null
    private var mcServer: WebSocketServer? = null
    private var voiceServer: WebSocketServer? = null

    private val msgRe = Regex("""VC\|(\d+)\|([01])\|(.*)$""")

    fun start() {
        try {
            mcServer = McServer().also { it.isReuseAddr = true; it.connectionLostTimeout = 0; it.start() }
        } catch (e: Throwable) { log("เปิดพอร์ต 19131 ไม่ได้: ${e.message}") }
        try {
            voiceServer = VoiceServer().also { it.isReuseAddr = true; it.isTcpNoDelay = true; it.connectionLostTimeout = 10; it.start() }
        } catch (e: Throwable) { log("เปิดพอร์ต 8080 ไม่ได้: ${e.message}") }
        scheduler.scheduleWithFixedDelay({
            try { queryPlayers() } catch (e: Exception) { }
        }, 500, 500, TimeUnit.MILLISECONDS)
        scheduler.scheduleWithFixedDelay({
            try { broadcastStatus() } catch (e: Exception) { }
        }, 1000, 1000, TimeUnit.MILLISECONDS)
    }

    fun stop() {
        scheduler.shutdownNow()
        try { mcServer?.stop(300) } catch (e: Exception) { }
        try { voiceServer?.stop(300) } catch (e: Exception) { }
    }

    // ---------- ส่งคำสั่งเข้า Minecraft ----------
    private fun mcSend(cmd: String): String? {
        val c = mc ?: return null
        if (!c.isOpen) return null
        val id = UUID.randomUUID().toString()
        val msg = JSONObject()
            .put("header", JSONObject().put("version", 1).put("requestId", id)
                .put("messagePurpose", "commandRequest").put("messageType", "commandRequest"))
            .put("body", JSONObject().put("version", 1).put("commandLine", cmd)
                .put("origin", JSONObject().put("type", "player")))
        c.send(msg.toString())
        return id
    }

    private fun queryPlayers() {
        for ((key, p) in players) {
            val id = mcSend("querytarget @a[name=\"${p.name}\"]")
            if (id != null) pending[id] = key
        }
        if (pending.size > 500) pending.clear()
    }

    private fun num(text: String, k: String): Double? =
        Regex("""\\?"$k\\?"\s*:\s*(-?[\d.]+)""").find(text)?.groupValues?.get(1)?.toDoubleOrNull()

    private fun handleMc(raw: String) {
        val j = try { JSONObject(raw) } catch (e: Exception) { return }
        val h = j.optJSONObject("header") ?: JSONObject()
        val b = j.optJSONObject("body") ?: JSONObject()

        if (h.optString("messagePurpose") == "commandResponse") {
            val key = pending.remove(h.optString("requestId")) ?: return
            val p = players[key] ?: return
            val text = b.optString("details") + b.optString("statusMessage")
            val x = num(text, "x"); val y = num(text, "y"); val z = num(text, "z")
            val d = num(text, "dimension")
            if (x == null || z == null) { p.pos = null; return }
            p.pos = doubleArrayOf(x, y ?: 0.0, z)
            p.dim = d?.toInt() ?: 0
            p.seen = System.currentTimeMillis()
            return
        }

        if (h.optString("eventName") == "PlayerMessage" || b.has("message")) {
            val msg = b.optString("message").replace(Regex("§."), "")
            val m = msgRe.find(msg)
            val sender = b.optString("sender")
            if (m != null && sender.isNotEmpty()) {
                val p = players.getOrPut(sender.lowercase()) { Player(sender) }
                p.name = sender
                p.range = m.groupValues[1].toIntOrNull() ?: 30
                p.muted = m.groupValues[2] == "1"
                p.call = m.groupValues[3].trim()
                p.seen = System.currentTimeMillis()
            }
        }
    }

    private fun fresh(p: Player) = System.currentTimeMillis() - p.seen < 15000

    private fun gainFor(s: Player, l: Player): Double {
        val sc = s.call.lowercase(); val lc = l.call.lowercase()
        if (sc.isNotEmpty() && lc.isNotEmpty() && sc == l.name.lowercase() && lc == s.name.lowercase()) return 1.0
        val sp = s.pos; val lp = l.pos
        if (sp == null || lp == null || s.dim != l.dim) return 0.0
        val dx = sp[0] - lp[0]; val dy = sp[1] - lp[1]; val dz = sp[2] - lp[2]
        val d = sqrt(dx * dx + dy * dy + dz * dz)
        val r = s.range.toDouble()
        if (d > r) return 0.0
        val near = r * 0.4
        if (d <= near) return 1.0
        return max(0.0, 1 - (d - near) / (r - near))
    }

    private fun playerList(): JSONArray {
        val list = JSONArray()
        for (p in players.values) {
            if (!fresh(p)) continue
            list.put(JSONObject().put("name", p.name).put("range", p.range)
                .put("muted", p.muted).put("call", p.call))
        }
        return list
    }

    private fun sendStatus(ws: WebSocket, c: Client, list: JSONArray) {
        val n = c.name
        if (!ws.isOpen || n == null) return
        val p = players[n.lowercase()]?.takeIf { fresh(it) }
        val o = JSONObject().put("t", "status").put("mc", mc?.isOpen == true).put("game", p != null)
            .put("range", p?.range ?: 0).put("muted", p?.muted ?: true)
            .put("call", p?.call ?: "").put("players", list)
        ws.send(o.toString())
    }

    private fun broadcastStatus() {
        val list = playerList()
        for ((ws, c) in clients) sendStatus(ws, c, list)
    }

    // ---------- เซิร์ฟเวอร์ที่ Minecraft มาเชื่อม (/wsserver) ----------
    private inner class McServer : WebSocketServer(InetSocketAddress("127.0.0.1", 19131)) {
        override fun onOpen(conn: WebSocket, handshake: ClientHandshake?) {
            mc = conn
            log("Minecraft เชื่อมต่อแล้ว")
            conn.send(JSONObject()
                .put("header", JSONObject().put("version", 1).put("requestId", UUID.randomUUID().toString())
                    .put("messagePurpose", "subscribe").put("messageType", "commandRequest"))
                .put("body", JSONObject().put("eventName", "PlayerMessage")).toString())
            mcSend("scriptevent vc:sync")
        }
        override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
            if (mc === conn) mc = null
            log("Minecraft ตัดการเชื่อมต่อ")
        }
        override fun onMessage(conn: WebSocket, message: String?) { if (message != null) handleMc(message) }
        override fun onError(conn: WebSocket?, ex: Exception?) { log("MC error: ${ex?.javaClass?.simpleName} ${ex?.message}") }
        override fun onStart() { log("พร้อมรอ Minecraft ที่ 127.0.0.1:19131") }
    }

    // ---------- เซิร์ฟเวอร์เสียงที่แอปทุกคนเชื่อม ----------
    private inner class VoiceServer : WebSocketServer(InetSocketAddress(8080)) {
        override fun onOpen(conn: WebSocket, handshake: ClientHandshake?) {
            clients[conn] = Client(nextId.getAndIncrement() % 250)
            log("มีไคลเอนต์เสียงเชื่อมเข้ามา")
        }
        override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
            clients.remove(conn)
        }
        override fun onError(conn: WebSocket?, ex: Exception?) { log("Voice error: ${ex?.javaClass?.simpleName} ${ex?.message}") }
        override fun onStart() { log("เซิร์ฟเวอร์เสียงพร้อมที่พอร์ต 8080") }

        override fun onMessage(conn: WebSocket, message: String?) {
            val c = clients[conn] ?: return
            val j = try { JSONObject(message ?: return) } catch (e: Exception) { return }
            when (j.optString("t")) {
                "join" -> {
                    c.name = j.optString("name").trim().take(32)
                    log("เข้าร่วมเสียง: ${c.name}")
                    sendStatus(conn, c, playerList())     // ส่งสถานะทันที ไม่ต้องรอรอบถัดไป
                    mcSend("scriptevent vc:sync")
                }
                "mute" -> {
                    val n = c.name ?: return
                    val p = players[n.lowercase()] ?: return
                    val m = if (j.optInt("m") == 1) 1 else 0
                    p.muted = m == 1
                    mcSend("scriptevent vc:mute $m|${p.name}")
                }
            }
        }

        override fun onMessage(conn: WebSocket, message: ByteBuffer?) {
            if (message == null) return
            val c = clients[conn] ?: return
            val name = c.name ?: return
            val s = players[name.lowercase()] ?: return
            if (s.muted || !fresh(s)) return
            val data = ByteArray(message.remaining()); message.get(data)
            for ((w2, c2) in clients) {
                if (w2 === conn || !w2.isOpen) continue
                val n2 = c2.name ?: continue
                val l = players[n2.lowercase()] ?: continue
                val g = gainFor(s, l)
                if (g < 0.02) continue
                val out = ByteArray(2 + data.size)
                out[0] = c.id.toByte()
                out[1] = (g * 255).roundToInt().toByte()
                System.arraycopy(data, 0, out, 2, data.size)
                w2.send(out)
            }
        }
    }
}
