package com.voicephone

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.SystemClock
import org.java_websocket.client.WebSocketClient
import org.java_websocket.drafts.Draft_6455
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONObject
import java.net.URI
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** ไคลเอนต์เสียง: จับไมค์ -> ส่งขึ้นเซิร์ฟเวอร์, รับเสียงคนอื่น -> เล่นออกลำโพง/หูฟัง */
class VoiceClient(
    private val url: String,
    private val name: String,
    private val onStatus: (Status) -> Unit,
    private val onClosed: (String) -> Unit,
) {
    data class PlayerInfo(val name: String, val muted: Boolean, val call: String)
    data class Status(
        val mc: Boolean, val game: Boolean, val muted: Boolean,
        val range: Int, val call: String, val players: List<PlayerInfo>,
    )

    private class Speaker(val track: AudioTrack) {
        var primed = false
        var queued = 0
        var last = 0L
    }

    companion object { const val SR = 16000 }

    @Volatile var muted = true
    @Volatile var level = 0f
    @Volatile private var running = false
    @Volatile private var opened = false
    @Volatile private var lastError = ""
    private var ws: WebSocketClient? = null
    private val speakers = HashMap<Int, Speaker>()
    private val playExec = Executors.newSingleThreadExecutor()

    fun start() {
        running = true
        // timeout 5 วินาที: ถ้าต่อโฮสต์ไม่ติดจะรู้ทันที (เดิมค้างได้เป็นนาที)
        val c = object : WebSocketClient(URI(url), Draft_6455(), null, 5000) {
            override fun onOpen(h: ServerHandshake?) {
                opened = true
                connectionLostTimeout = 10
                VoiceService.addLog("เชื่อมเซิร์ฟเวอร์เสียงสำเร็จ")
                send(JSONObject().put("t", "join").put("name", name).toString())
                startMic()
            }
            override fun onMessage(message: String?) { handleText(message ?: return) }
            override fun onMessage(bytes: ByteBuffer?) { handleAudio(bytes ?: return) }
            override fun onClose(code: Int, reason: String?, remote: Boolean) {
                VoiceService.addLog("ปิดการเชื่อมต่อ code=$code ${reason ?: ""}")
                val unexpected = running
                running = false
                releaseAudio()
                if (unexpected) onClosed(
                    if (!opened) "ต่อโฮสต์ไม่ติด — เช็กว่าอยู่ wifi/ฮอตสปอตเดียวกับโฮสต์ และ IP:พอร์ตถูกต้อง"
                    else if (lastError.isNotEmpty()) lastError else "สัญญาณขาดหาย")
            }
            override fun onError(ex: Exception?) {
                lastError = ex?.message ?: ""
                VoiceService.addLog("client error: ${ex?.javaClass?.simpleName} ${ex?.message}")
            }
        }
        ws = c
        c.isTcpNoDelay = true
        c.connect()
    }

    fun stop() {
        running = false
        try { ws?.close() } catch (e: Exception) { }
        releaseAudio()
    }

    fun toggleMute() {
        val want = if (muted) 0 else 1
        muted = want == 1
        try { ws?.send(JSONObject().put("t", "mute").put("m", want).toString()) } catch (e: Exception) { }
    }

    private fun handleText(s: String) {
        val j = try { JSONObject(s) } catch (e: Exception) { return }
        if (j.optString("t") != "status") return
        val arr = j.optJSONArray("players")
        val list = ArrayList<PlayerInfo>()
        if (arr != null) for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(PlayerInfo(o.optString("name"), o.optBoolean("muted"), o.optString("call")))
        }
        muted = j.optBoolean("muted", true)
        onStatus(Status(j.optBoolean("mc"), j.optBoolean("game"), muted,
            j.optInt("range"), j.optString("call"), list))
    }

    // ---------- ไมค์ ----------
    @SuppressLint("MissingPermission")
    private fun startMic() {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SR,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 8192))
        thread(name = "vc-mic") {
            val buf = ShortArray(1024)
            var gateUntil = 0L
            try {
                rec.startRecording()
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    var sum = 0.0
                    for (i in 0 until n) { val v = buf[i] / 32768.0; sum += v * v }
                    val rms = sqrt(sum / n)
                    level = min(1f, (rms * 5).toFloat())
                    val now = SystemClock.elapsedRealtime()
                    if (rms > 0.012) gateUntil = now + 400
                    val w = ws
                    if (muted || now > gateUntil || w == null || !w.isOpen) continue
                    val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until n) bb.putShort(buf[i])
                    w.send(bb.array())
                }
            } catch (e: Exception) {
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                rec.release()
            }
        }
    }

    // ---------- เล่นเสียงคนอื่น ----------
    private fun newTrack(): AudioTrack {
        val min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(SR)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(min, SR))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    private fun handleAudio(b: ByteBuffer) {
        val arr = ByteArray(b.remaining()); b.get(arr)
        if (arr.size <= 2) return
        val id = arr[0].toInt() and 0xFF
        val gain = (arr[1].toInt() and 0xFF) / 255f
        try { playExec.execute {
            try {
                val sp = speakers.getOrPut(id) { Speaker(newTrack()) }
                val now = SystemClock.elapsedRealtime()
                if (sp.primed && now - sp.last > 300) {   // เงียบนาน -> เตรียมบัฟเฟอร์ใหม่
                    sp.track.pause(); sp.track.flush(); sp.primed = false; sp.queued = 0
                }
                sp.track.setVolume(gain)
                val n = sp.track.write(arr, 2, arr.size - 2, AudioTrack.WRITE_NON_BLOCKING)
                if (n > 0) sp.queued += n
                if (!sp.primed && sp.queued >= 3200) { sp.track.play(); sp.primed = true }
                sp.last = now
            } catch (e: Exception) { }
        } } catch (e: Exception) { }
    }

    private fun releaseAudio() {
        try {
            playExec.execute {
                for (sp in speakers.values) { try { sp.track.stop(); sp.track.release() } catch (e: Exception) { } }
                speakers.clear()
            }
            playExec.shutdown()
        } catch (e: Exception) { }
    }
}
